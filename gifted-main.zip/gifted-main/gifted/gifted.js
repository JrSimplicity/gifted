const _0x35e6c7 = _0x2c09;
(function (_0x2c023b, _0x35387d) {
    const _0x58603f = _0x2c09, _0xfc9d03 = _0x2c023b();
    while (!![]) {
        try {
            const _0x39fb3c = -parseInt(_0x58603f(0x143)) / 0x1 + -parseInt(_0x58603f(0x139)) / 0x2 + parseInt(_0x58603f(0x137)) / 0x3 + -parseInt(_0x58603f(0x11a)) / 0x4 + parseInt(_0x58603f(0x10b)) / 0x5 + -parseInt(_0x58603f(0x131)) / 0x6 + parseInt(_0x58603f(0xff)) / 0x7;
            if (_0x39fb3c === _0x35387d)
                break;
            else
                _0xfc9d03['push'](_0xfc9d03['shift']());
        } catch (_0x351035) {
            _0xfc9d03['push'](_0xfc9d03['shift']());
        }
    }
}(_0x4199, 0xa58e9));
import _0x440176 from 'dotenv';
_0x440176['config']();
import {
    makeWASocket,
    Browsers,
    jidDecode,
    makeInMemoryStore,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion,
    DisconnectReason,
    useMultiFileAuthState,
    getAggregateVotesInPollMessage
} from 'gifted-baileys';
import {
    Handler,
    Callupdate,
    GroupUpdate
} from './funcs/giftedte.js';
import { Boom } from '@hapi/boom';
import _0x2fdd16 from 'express';
import _0x3f287a from 'pino';
import _0x4345ee from 'fs';
import _0xcc432d from 'node-cache';
import _0x851f82 from 'path';
function _0x2c09(_0x373110, _0x23ae61) {
    const _0x4199b6 = _0x4199();
    return _0x2c09 = function (_0x2c0975, _0x41000c) {
        _0x2c0975 = _0x2c0975 - 0xf7;
        let _0x480548 = _0x4199b6[_0x2c0975];
        return _0x480548;
    }, _0x2c09(_0x373110, _0x23ae61);
}
import _0x40852b from 'chalk';
import { writeFile } from 'fs/promises';
import _0x8ffe51 from 'moment-timezone';
import _0x56e46e from 'axios';
import _0x5da85d from 'node-fetch';
import * as _0xcdbbc7 from 'os';
import _0x5f3656 from '../set.cjs';
import _0x48a30b from '../gift/giftke.cjs';
function _0x4199() {
    const _0x2475a8 = [
        'send',
        'fatal',
        'toJSON',
        '✅WHATSAPP\x20LOGIN\x20SUCCESSFUL,\x20𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓\x20𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃',
        '638358kAzFAs',
        'error',
        'writeFileSync',
        'public',
        'red',
        'store',
        '3752316dnFyBN',
        'timedOut',
        '2061470XQZTaK',
        'Linux',
        'exit',
        'child',
        'env',
        'join',
        '✅WHATSAPP\x20LOGIN\x20SUCCESSFUL,\x20𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓\x20𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃!',
        'platform',
        'fromMe',
        'close',
        '504771WFOkVQ',
        ',\x22time\x22:\x22',
        'CHECKING\x20WA\x20VERSION\x20v',
        'call',
        'message',
        'remoteJid',
        'user',
        '𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓\x20𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃\x0a\x0a𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞\x20\x20:\x20Cpanel\x20\x0a𝐏𝐥𝐚𝐭𝐟𝐨𝐫𝐦:\x20Whatsapp\x20\x0a𝐎𝐰𝐧𝐞𝐫\x20\x20\x20\x20:\x20t.me/mouricedevs\x0a𝐓𝐮𝐭𝐨𝐫𝐢𝐚𝐥𝐬\x20\x20:\x20youtube.com/@giftedtechnexus\x0a𝐖𝐚𝐂𝐡𝐚𝐧𝐧𝐞𝐥\x20:\x20https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l\x0a\x0a>\x20𝐏𝐎𝐖𝐄𝐑𝐄𝐃\x20𝐁𝐘\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐓𝐄𝐂𝐇',
        'bind',
        '[😩]\x20Connection\x20closed,\x20reconnecting.',
        'keys',
        'messages',
        'buttonsMessage',
        'loggedOut',
        './session/creds.json',
        'text',
        '[⏳]\x20Connection\x20Timed\x20Out,\x20Trying\x20to\x20Reconnect.',
        'session',
        '13208993soCUHO',
        'MODE',
        'get',
        'authState',
        'connection.update',
        'creds',
        'Gifted\x20Server\x20Live\x20on\x20Port\x20',
        'bold',
        'SESSION_ID',
        'Creds.json\x20file\x20saved\x20in\x20Session\x20Folder',
        'darwin',
        'split',
        '246750hJCYHl',
        '121.0.6167.159',
        'MacOS',
        'green',
        'statusCode',
        'sendMessage',
        'registered',
        '[🤕]\x20Connection\x20Lost\x20from\x20Server,\x20reconnecting.',
        '#FFA500',
        'string',
        'connectionClosed',
        '#32CD32',
        'PORT',
        '[♻️]\x20Server\x20Restarting.',
        'loadMessage',
        '3468404atNBEH',
        '♻️\x20Connection\x20reestablished\x20after\x20restart.',
        'hex',
        'GIFTED\x20CONNECTING\x20TO\x20WHATSAPP',
        '[😭]\x20Device\x20Logged\x20Out,\x20Please\x20Delete\x20Session\x20and\x20Link\x20Again.',
        'listMessage',
        'blue',
        'silent',
        'AUTO_REACT',
        'log',
        'Session\x20ID\x20Converted\x20to\x20creds.json',
        'chrome',
        'messages.upsert',
        'floor',
        'private',
        'open',
        'win32',
        'listen',
        'Windows'
    ];
    _0x4199 = function () {
        return _0x2475a8;
    };
    return _0x4199();
}
const {emojis, doReact} = _0x48a30b, sessionName = _0x35e6c7(0xfe), app = _0x2fdd16(), orange = _0x40852b[_0x35e6c7(0x106)]['hex'](_0x35e6c7(0x113)), lime = _0x40852b['bold'][_0x35e6c7(0x11c)](_0x35e6c7(0x116));
let useQR, isSessionPutted, initialConnection = !![];
const PORT = process[_0x35e6c7(0x13d)][_0x35e6c7(0x117)] || 0x1388, MAIN_LOGGER = _0x3f287a({ 'timestamp': () => _0x35e6c7(0x144) + new Date()[_0x35e6c7(0x12f)]() + '\x22' }), logger = MAIN_LOGGER[_0x35e6c7(0x13c)]({});
logger['level'] = 'trace';
const msgRetryCounterCache = new _0xcc432d(), store = makeInMemoryStore({
        'logger': _0x3f287a()['child']({
            'level': 'silent',
            'stream': _0x35e6c7(0x136)
        })
    });
async function start() {
    const _0x3108c0 = _0x35e6c7;
    !_0x5f3656[_0x3108c0(0x107)] ? (useQR = ![], isSessionPutted = ![]) : (useQR = ![], isSessionPutted = !![]);
    let {
            state: _0x5a4a3b,
            saveCreds: _0x360870
        } = await useMultiFileAuthState(sessionName), {
            version: _0x34dfee,
            isLatest: _0x7f3df7
        } = await fetchLatestBaileysVersion();
    console[_0x3108c0(0x123)](_0x40852b['red'](_0x3108c0(0x11d))), console[_0x3108c0(0x123)](_0x40852b[_0x3108c0(0x10e)](_0x3108c0(0x145) + _0x34dfee[_0x3108c0(0x13e)]('.') + ',\x20isLatest:\x20' + _0x7f3df7));
    const _0x4587da = _0xcdbbc7[_0x3108c0(0x140)]() === _0x3108c0(0x12a) ? _0x3108c0(0x12c) : _0xcdbbc7[_0x3108c0(0x140)]() === _0x3108c0(0x109) ? _0x3108c0(0x10d) : _0x3108c0(0x13a), _0x15c7bc = makeWASocket({
            'version': _0x34dfee,
            'logger': _0x3f287a({ 'level': _0x3108c0(0x121) }),
            'printQRInTerminal': useQR,
            'browser': [
                _0x4587da,
                _0x3108c0(0x125),
                _0x3108c0(0x10c)
            ],
            'patchMessageBeforeSending': _0x5ee502 => {
                const _0x3205ea = _0x3108c0, _0x10c702 = !!(_0x5ee502[_0x3205ea(0xf9)] || _0x5ee502['templateMessage'] || _0x5ee502[_0x3205ea(0x11f)]);
                return _0x10c702 && (_0x5ee502 = {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadataVersion': 0x2,
                                'deviceListMetadata': {}
                            },
                            ..._0x5ee502
                        }
                    }
                }), _0x5ee502;
            },
            'auth': {
                'creds': _0x5a4a3b[_0x3108c0(0x104)],
                'keys': makeCacheableSignalKeyStore(_0x5a4a3b[_0x3108c0(0xf7)], _0x3f287a({ 'level': 'fatal' })[_0x3108c0(0x13c)]({ 'level': _0x3108c0(0x12e) }))
            },
            'getMessage': async _0x9a59ca => {
                const _0x331103 = _0x3108c0;
                if (store) {
                    const _0x32840b = await store[_0x331103(0x119)](_0x9a59ca[_0x331103(0x148)], _0x9a59ca['id']);
                    return _0x32840b[_0x331103(0x147)] || undefined;
                }
                return { 'conversation': _0x331103(0x13f) };
            },
            'markOnlineOnConnect': !![],
            'generateHighQualityLinkPreview': !![],
            'defaultQueryTimeoutMs': undefined,
            'msgRetryCounterCache': msgRetryCounterCache
        });
    store?.[_0x3108c0(0x14b)](_0x15c7bc['ev']);
    if (!_0x15c7bc[_0x3108c0(0x102)][_0x3108c0(0x104)][_0x3108c0(0x111)] && isSessionPutted) {
        const _0x186b2e = _0x5f3656[_0x3108c0(0x107)][_0x3108c0(0x10a)]('Gifted~')[0x1], _0x1623b7 = 'https://pastebin.com/raw/' + _0x186b2e, _0x540111 = await _0x5da85d(_0x1623b7), _0x15983a = await _0x540111[_0x3108c0(0xfc)]();
        typeof _0x15983a === _0x3108c0(0x114) && (_0x4345ee[_0x3108c0(0x133)](_0x3108c0(0xfb), _0x15983a), console[_0x3108c0(0x123)](_0x3108c0(0x124)), console[_0x3108c0(0x123)](_0x3108c0(0x108)), await start());
    }
    async function _0x16d2f6(_0x3ab6e9) {
        const _0x5c496f = _0x3108c0;
        if (store) {
            const _0x3b9563 = await store['loadMessage'](_0x3ab6e9[_0x5c496f(0x148)], _0x3ab6e9['id']);
            return _0x3b9563?.['message'];
        }
        return { 'conversation': _0x5c496f(0x13f) };
    }
    _0x15c7bc['ev']['on'](_0x3108c0(0x126), async _0x6c5cbb => await Handler(_0x6c5cbb, _0x15c7bc, logger)), _0x15c7bc['ev']['on'](_0x3108c0(0x146), async _0xba9c06 => await Callupdate(_0xba9c06, _0x15c7bc)), _0x15c7bc['ev']['on']('group-participants.update', async _0x1822cb => await GroupUpdate(_0x15c7bc, _0x1822cb));
    if (_0x5f3656[_0x3108c0(0x100)] === 'public')
        _0x15c7bc[_0x3108c0(0x134)] = !![];
    else
        _0x5f3656[_0x3108c0(0x100)] === _0x3108c0(0x128) && (_0x15c7bc[_0x3108c0(0x134)] = ![]);
    _0x15c7bc['ev']['on'](_0x3108c0(0x103), async _0x9ce681 => {
        const _0x50ceea = _0x3108c0, {
                connection: _0x1b9e55,
                lastDisconnect: _0x4ce021
            } = _0x9ce681;
        if (_0x1b9e55 === _0x50ceea(0x142)) {
            let _0xa48e55 = new Boom(_0x4ce021?.[_0x50ceea(0x132)])?.['output'][_0x50ceea(0x10f)];
            if (_0xa48e55 === DisconnectReason[_0x50ceea(0x115)])
                console['log'](_0x40852b[_0x50ceea(0x135)](_0x50ceea(0x14c))), start();
            else {
                if (_0xa48e55 === DisconnectReason['connectionLost'])
                    console[_0x50ceea(0x123)](_0x40852b[_0x50ceea(0x135)](_0x50ceea(0x112))), start();
                else {
                    if (_0xa48e55 === DisconnectReason[_0x50ceea(0xfa)])
                        console[_0x50ceea(0x123)](_0x40852b[_0x50ceea(0x135)](_0x50ceea(0x11e))), process[_0x50ceea(0x13b)]();
                    else {
                        if (_0xa48e55 === DisconnectReason['restartRequired'])
                            console[_0x50ceea(0x123)](_0x40852b[_0x50ceea(0x120)](_0x50ceea(0x118))), start();
                        else
                            _0xa48e55 === DisconnectReason[_0x50ceea(0x138)] && (console[_0x50ceea(0x123)](_0x40852b[_0x50ceea(0x135)](_0x50ceea(0xfd))), start());
                    }
                }
            }
        }
        _0x1b9e55 === _0x50ceea(0x129) && (initialConnection ? (console[_0x50ceea(0x123)](_0x40852b[_0x50ceea(0x10e)](_0x50ceea(0x130))), _0x15c7bc[_0x50ceea(0x110)](_0x15c7bc[_0x50ceea(0x149)]['id'], { 'text': _0x50ceea(0x14a) }), initialConnection = ![]) : console[_0x50ceea(0x123)](_0x40852b[_0x50ceea(0x120)](_0x50ceea(0x11b))));
    }), _0x15c7bc['ev']['on'](_0x3108c0(0x126), async _0x1229c5 => {
        const _0x1ee762 = _0x3108c0;
        try {
            const _0x289067 = _0x1229c5[_0x1ee762(0xf8)][0x0];
            if (!_0x289067['key'][_0x1ee762(0x141)] && _0x5f3656[_0x1ee762(0x122)]) {
                console[_0x1ee762(0x123)](_0x289067);
                if (_0x289067['message']) {
                    const _0x31e4c9 = emojis[Math[_0x1ee762(0x127)](Math['random']() * emojis['length'])];
                    await doReact(_0x31e4c9, _0x289067, _0x15c7bc);
                }
            }
        } catch (_0x2ba64f) {
            console[_0x1ee762(0x132)]('Error\x20during\x20auto\x20reaction:', _0x2ba64f);
        }
    });
}
start(), app[_0x35e6c7(0x101)]('/', (_0xd05c16, _0xbb499e) => {
    const _0x3c68f8 = _0x35e6c7;
    _0xbb499e[_0x3c68f8(0x12d)](_0x3c68f8(0x13f));
}), app[_0x35e6c7(0x12b)](PORT, () => {
    const _0x59af14 = _0x35e6c7;
    console[_0x59af14(0x123)](_0x59af14(0x105) + PORT);
});
