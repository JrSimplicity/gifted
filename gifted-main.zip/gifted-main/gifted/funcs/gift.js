(function (_0x9f9cd6, _0x49354b) {
    const _0x165e4f = _0x12d6, _0x3da652 = _0x9f9cd6();
    while (!![]) {
        try {
            const _0x1101ef = -parseInt(_0x165e4f(0xfc)) / (-0xb8b + 0x2597 + -0x71 * 0x3b) * (parseInt(_0x165e4f(0x11e)) / (-0x15db + 0x1cc * -0x14 + 0x39cd * 0x1)) + parseInt(_0x165e4f(0x118)) / (-0x5b4 + -0x1fd6 + 0x1 * 0x258d) * (-parseInt(_0x165e4f(0x11c)) / (-0x14b8 + -0x2696 + 0x3b52)) + parseInt(_0x165e4f(0x11f)) / (-0x17bc + 0x2166 + -0x3 * 0x337) + -parseInt(_0x165e4f(0x136)) / (-0xb5 * -0x17 + 0x1f40 + -0x2f7d) * (-parseInt(_0x165e4f(0x123)) / (-0x1325 + -0x1 * 0x1c95 + -0x5 * -0x98d)) + parseInt(_0x165e4f(0x119)) / (0x1 * -0x1049 + -0x7b8 + -0x803 * -0x3) + parseInt(_0x165e4f(0x141)) / (-0x22bc + 0x213 * -0x3 + 0x16 * 0x1dd) * (parseInt(_0x165e4f(0x128)) / (0x65 * -0x49 + 0x2275 + 0x2 * -0x2cf)) + -parseInt(_0x165e4f(0x13f)) / (-0xc19 * 0x3 + 0x26d0 + 0x1 * -0x27a);
            if (_0x1101ef === _0x49354b)
                break;
            else
                _0x3da652['push'](_0x3da652['shift']());
        } catch (_0x276503) {
            _0x3da652['push'](_0x3da652['shift']());
        }
    }
}(_0xc1f0, 0x4b13d + 0x72686 + -0x1a11 * 0x41));
import _0x35252a from 'moment-timezone';
function _0x12d6(_0x44ac24, _0x5dee1c) {
    const _0x3fe006 = _0xc1f0();
    return _0x12d6 = function (_0x1cabb4, _0x4e2eb9) {
        _0x1cabb4 = _0x1cabb4 - (0xc99 + 0xa6d + -0x1614);
        let _0x5cb7d9 = _0x3fe006[_0x1cabb4];
        return _0x5cb7d9;
    }, _0x12d6(_0x44ac24, _0x5dee1c);
}
import _0x5e15c5 from '../../set.cjs';
export default async function GroupParticipants(_0xda8ab3, {
    id: _0x50625a,
    participants: _0x4de223,
    action: _0x1c173f
}) {
    const _0x516f8a = _0x12d6, _0x564685 = {
            'EZAuY': _0x516f8a(0x103),
            'yvsTT': _0x516f8a(0xfb) + _0x516f8a(0xfa) + _0x516f8a(0x100) + _0x516f8a(0x137) + _0x516f8a(0x12a) + _0x516f8a(0xfd) + _0x516f8a(0x132) + _0x516f8a(0x146) + _0x516f8a(0x143) + _0x516f8a(0xf4) + _0x516f8a(0x13a) + _0x516f8a(0x13b) + _0x516f8a(0x120) + _0x516f8a(0x138) + _0x516f8a(0xf5) + _0x516f8a(0x124) + _0x516f8a(0x10e) + _0x516f8a(0x13d) + _0x516f8a(0x10b) + _0x516f8a(0xf7) + _0x516f8a(0x113),
            'lPkZu': function (_0x48043b, _0x326612) {
                return _0x48043b == _0x326612;
            },
            'UCgsB': _0x516f8a(0x140),
            'TGnPL': _0x516f8a(0x144) + _0x516f8a(0x106),
            'RQwiN': _0x516f8a(0x115),
            'xTxsp': _0x516f8a(0x133),
            'lUqOY': _0x516f8a(0x108) + _0x516f8a(0x116) + _0x516f8a(0x12b) + _0x516f8a(0x129) + _0x516f8a(0x10a) + _0x516f8a(0xf3),
            'ZjjIY': function (_0x1b5061, _0xe7947d) {
                return _0x1b5061 == _0xe7947d;
            },
            'teTnH': _0x516f8a(0x110)
        };
    try {
        const _0x464d74 = await _0xda8ab3[_0x516f8a(0x111) + _0x516f8a(0x109)](_0x50625a);
        for (const _0xa9fa0d of _0x4de223) {
            let _0x1a9421;
            try {
                _0x1a9421 = await _0xda8ab3[_0x516f8a(0x126) + _0x516f8a(0x102)](_0xa9fa0d, _0x564685[_0x516f8a(0x114)]);
            } catch {
                _0x1a9421 = _0x564685[_0x516f8a(0x101)];
            }
            if (_0x564685[_0x516f8a(0x11d)](_0x1c173f, _0x564685[_0x516f8a(0x142)]) && _0x5e15c5[_0x516f8a(0x12e)]) {
                const _0x10003a = _0xa9fa0d[_0x516f8a(0x112)]('@')[0x2534 + -0xb71 + -0x19c3], _0x16dde0 = _0x35252a['tz'](_0x564685[_0x516f8a(0x135)])[_0x516f8a(0x121)](_0x564685[_0x516f8a(0xf9)]), _0x4d06cc = _0x35252a['tz'](_0x564685[_0x516f8a(0x135)])[_0x516f8a(0x121)](_0x564685[_0x516f8a(0x13e)]), _0x410ee3 = _0x464d74[_0x516f8a(0x12d) + 'ts'][_0x516f8a(0xf8)];
                _0xda8ab3[_0x516f8a(0x12c) + 'e'](_0x50625a, {
                    'text': _0x516f8a(0x117) + _0x10003a + (_0x516f8a(0x11b) + _0x516f8a(0x127)) + _0x464d74[_0x516f8a(0xff)] + (_0x516f8a(0x11a) + _0x516f8a(0x10f)) + _0x410ee3 + (_0x516f8a(0x105) + _0x516f8a(0xf2) + _0x516f8a(0x134)) + _0x16dde0 + _0x516f8a(0xfe) + _0x4d06cc + '\x0a\x22',
                    'contextInfo': {
                        'mentionedJid': [_0xa9fa0d],
                        'externalAdReply': {
                            'title': _0x516f8a(0x125) + _0x516f8a(0x107),
                            'mediaType': 0x1,
                            'previewType': 0x0,
                            'renderLargerThumbnail': !![],
                            'thumbnailUrl': _0x464d74[_0x516f8a(0xff)],
                            'sourceUrl': _0x564685[_0x516f8a(0x122)]
                        }
                    }
                });
            } else {
                if (_0x564685[_0x516f8a(0x131)](_0x1c173f, _0x564685[_0x516f8a(0x10d)]) && _0x5e15c5[_0x516f8a(0x12e)]) {
                    const _0x16c3e6 = _0xa9fa0d[_0x516f8a(0x112)]('@')[0xa47 * 0x3 + -0x11e7 + -0xcee], _0x45b2b3 = _0x35252a['tz'](_0x564685[_0x516f8a(0x135)])[_0x516f8a(0x121)](_0x564685[_0x516f8a(0xf9)]), _0x1c24c4 = _0x35252a['tz'](_0x564685[_0x516f8a(0x135)])[_0x516f8a(0x121)](_0x564685[_0x516f8a(0x13e)]), _0x199513 = _0x464d74[_0x516f8a(0x12d) + 'ts'][_0x516f8a(0xf8)];
                    _0xda8ab3[_0x516f8a(0x12c) + 'e'](_0x50625a, {
                        'text': _0x516f8a(0x10c) + '@' + _0x16c3e6 + _0x516f8a(0x12f) + _0x464d74[_0x516f8a(0xff)] + (_0x516f8a(0x104) + _0x516f8a(0xf6)) + _0x199513 + (_0x516f8a(0x130) + _0x516f8a(0x139) + _0x516f8a(0x145)) + _0x45b2b3 + _0x516f8a(0xfe) + _0x1c24c4 + '\x22',
                        'contextInfo': {
                            'mentionedJid': [_0xa9fa0d],
                            'externalAdReply': {
                                'title': _0x516f8a(0x13c) + 't',
                                'mediaType': 0x1,
                                'previewType': 0x0,
                                'renderLargerThumbnail': !![],
                                'thumbnailUrl': _0x1a9421,
                                'sourceUrl': _0x564685[_0x516f8a(0x122)]
                            }
                        }
                    });
                }
            }
        }
    } catch (_0x212ff7) {
        throw _0x212ff7;
    }
}
function _0xc1f0() {
    const _0x4ecf3c = [
        '\x20now\x20',
        'h630-p-k-n',
        'length',
        'RQwiN',
        '3.googleus',
        'https://lh',
        '1QQYKXs',
        'hgNYXqU8Gf',
        '\x20on\x20',
        'subject',
        'ercontent.',
        'yvsTT',
        'tureUrl',
        'image',
        '.\x0a>\x20We\x20are',
        'th\x20member.',
        'robi',
        'ned',
        'https://wh',
        'ata',
        'ISTkHTj4xv',
        'DGY=w1200-',
        '>\x20Goodbye\x20',
        'teTnH',
        '59pik9mnQ1',
        're\x20the\x20',
        'remove',
        'groupMetad',
        'split',
        'o-nu',
        'EZAuY',
        'HH:mm:ss',
        'atsapp.com',
        '>\x20Hello\x20@',
        '341955mTzINg',
        '3239552ZQfULv',
        '*.\x0a>\x20You\x20a',
        '!\x20Welcome\x20',
        '20vfyTCA',
        'lPkZu',
        '639486BAhRdp',
        '2509050qUBjQx',
        'aeTuCjp7xZ',
        'format',
        'lUqOY',
        '2625Tiypmo',
        'VqBoT7MJ02',
        'Member\x20Joi',
        'profilePic',
        'to\x20*',
        '6681850Ocfhlk',
        '029VaYauR9',
        'esjjzRYoXl',
        '/channel/0',
        'sendMessag',
        'participan',
        'WELCOME',
        '\x20from\x20',
        '\x20in\x20the\x20gr',
        'ZjjIY',
        '_3lu6V-eON',
        'DD/MM/YYYY',
        'at:\x20',
        'TGnPL',
        '8202clmaxE',
        'com/proxy/',
        'lpL48JDx-q',
        'oup.\x0a>\x20Lef',
        'caRIZF_0Uq',
        'b5U8NWNrJc',
        'Member\x20Lef',
        'LldFLfHZUG',
        'xTxsp',
        '9410610Fancfr',
        'add',
        '9SVKUDk',
        'UCgsB',
        '6F6z0MWAqI',
        'Africa/Nai',
        't\x20at:\x20',
        'TnymkLzdwQ',
        '\x0a>\x20Joined\x20',
        'i1l',
        'wIpqgq_lk4',
        'zAXSTh00AV'
    ];
    _0xc1f0 = function () {
        return _0x4ecf3c;
    };
    return _0xc1f0();
}
