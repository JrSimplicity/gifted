function _0x547e(_0x1a20a7, _0x2e0bba) {
    const _0x374d63 = _0x374d();
    return _0x547e = function (_0x547eb1, _0x24c202) {
        _0x547eb1 = _0x547eb1 - 0x11e;
        let _0x133bcd = _0x374d63[_0x547eb1];
        return _0x133bcd;
    }, _0x547e(_0x1a20a7, _0x2e0bba);
}
(function (_0x474b93, _0x2cc01e) {
    const _0xb4b33 = _0x547e, _0x12f7ee = _0x474b93();
    while (!![]) {
        try {
            const _0x374f7f = parseInt(_0xb4b33(0x127)) / 0x1 * (parseInt(_0xb4b33(0x12f)) / 0x2) + parseInt(_0xb4b33(0x11f)) / 0x3 + -parseInt(_0xb4b33(0x158)) / 0x4 * (parseInt(_0xb4b33(0x14b)) / 0x5) + -parseInt(_0xb4b33(0x13a)) / 0x6 + parseInt(_0xb4b33(0x156)) / 0x7 + -parseInt(_0xb4b33(0x14a)) / 0x8 * (parseInt(_0xb4b33(0x12a)) / 0x9) + -parseInt(_0xb4b33(0x146)) / 0xa * (-parseInt(_0xb4b33(0x155)) / 0xb);
            if (_0x374f7f === _0x2cc01e)
                break;
            else
                _0x12f7ee['push'](_0x12f7ee['shift']());
        } catch (_0x5b0624) {
            _0x12f7ee['push'](_0x12f7ee['shift']());
        }
    }
}(_0x374d, 0xd83f8));
function _0x374d() {
    const _0x21ae4c = [
        '306645KQMVjp',
        '.mp3',
        'body',
        'includes',
        'Error\x20from\x20Gifted\x20API:',
        'reply',
        'error',
        'test',
        '\x0a\x0a╭────────────────◆\x0a│\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*\x0a╰─────────────────◆',
        'timestamp',
        '44ztQpdd',
        '6936181mPzHHs',
        'thumbnail',
        '76ICGQWj',
        'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l',
        '3520806UqcQlL',
        'https://gifted-apis-third-30b2fdbb9819.herokuapp.com',
        'success',
        '*𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐒𝐎𝐍𝐆\x20𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑*\x0a\x0a╭───────────────◆\x0a│⿻\x20*Title:*\x20',
        'result',
        'match',
        'download_url',
        'length',
        '672437SJDxpj',
        'title',
        'type',
        '2457VepLxu',
        '*\x20to\x20download\x20it\x20as\x20normal\x20audio\x20format',
        'slice',
        '*_\x20,\x20Please\x20provide\x20the\x20song\x20name\x20or\x20YouTube\x20URL,\x20eg\x20*.ytmp3\x20Spectre\x20by\x20Alan\x20Walker*\x20or\x20*.ytmp3\x20https://www.youtube.com/watch?v=abc123*',
        'from',
        '2SOpKLW',
        'toLowerCase',
        'views',
        'https://telegra.ph/file/c2a4d8d65722553da4c89.jpg',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Processing\x20from\x20GiftedAPi...',
        'trim',
        'Failed\x20with\x20error\x20from\x20Gifted\x20API.\x20Please\x20try\x20again\x20later.',
        'Powered\x20by\x20Gifted\x20Tech',
        'quality',
        'json',
        '7636854voxeJR',
        '│⿻\x20*Duration:*\x20',
        '\x0a╰────────────────◆\x0a⦿\x20*Direct\x20Yt\x20Link:*\x20',
        '\x0a│⿻\x20*Quality:*\x20',
        '*\x0aUse\x20*.play\x20',
        'author',
        '/api/download/ytmp3?url=',
        'giftedtechk',
        'status',
        'ago',
        'sendMessage',
        'buffer',
        '3697430CHxwRV',
        'pushName',
        'React',
        'audio/mp4',
        '29072IqVVMF'
    ];
    _0x374d = function () {
        return _0x21ae4c;
    };
    return _0x374d();
}
import _0x211fe2 from 'node-fetch';
import _0x14ed12 from 'yt-search';
const Play = async (_0x1579ee, _0x68b1a1) => {
    const _0x113d29 = _0x547e, _0x2fcfb1 = _0x1579ee[_0x113d29(0x14d)][_0x113d29(0x124)](/^[\\/!#.]/), _0x1b937e = _0x2fcfb1 ? _0x2fcfb1[0x0] : '/', _0x26ceac = _0x113d29(0x120), _0x33e36d = _0x113d29(0x141), _0xfaa7be = _0x1579ee[_0x113d29(0x14d)]['startsWith'](_0x1b937e) ? _0x1579ee[_0x113d29(0x14d)][_0x113d29(0x12c)](_0x1b937e[_0x113d29(0x126)])['split']('\x20')[0x0][_0x113d29(0x130)]() : '', _0x35755f = _0x1579ee['body'][_0x113d29(0x12c)](_0x1b937e[_0x113d29(0x126)] + _0xfaa7be[_0x113d29(0x126)])[_0x113d29(0x135)](), _0x2b6b42 = ['song'];
    if (_0x2b6b42[_0x113d29(0x14e)](_0xfaa7be)) {
        if (!_0x35755f) {
            await _0x1579ee[_0x113d29(0x150)]('Hello\x20_*' + _0x1579ee[_0x113d29(0x147)] + _0x113d29(0x12d));
            return;
        }
        try {
            await _0x1579ee[_0x113d29(0x148)]('🕘'), await _0x1579ee[_0x113d29(0x150)](_0x113d29(0x134));
            let _0x2663e5 = _0x35755f, _0x69ed0a = [], _0x13008d = {};
            const _0xfd5630 = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/, _0x3a1e28 = _0xfd5630[_0x113d29(0x152)](_0x35755f);
            if (!_0x3a1e28) {
                const _0x47bdf1 = await _0x14ed12(_0x35755f);
                _0x69ed0a = _0x47bdf1['videos'];
                if (_0x69ed0a && _0x69ed0a[_0x113d29(0x126)] > 0x0 && _0x69ed0a[0x0])
                    _0x2663e5 = _0x69ed0a[0x0]['url'];
                else {
                    await _0x1579ee['reply']('No\x20audios\x20found.');
                    return;
                }
            }
            const _0x4c3da3 = await _0x211fe2(_0x26ceac + _0x113d29(0x140) + encodeURIComponent(_0x2663e5) + '&apikey=' + _0x33e36d), _0x185b60 = await _0x4c3da3[_0x113d29(0x139)]();
            if (_0x185b60[_0x113d29(0x142)] === 0xc8 && _0x185b60[_0x113d29(0x121)]) {
                const _0x11a4b4 = _0x185b60[_0x113d29(0x123)][_0x113d29(0x125)], _0x1ae1bd = await _0x211fe2(_0x11a4b4), _0x25e6f9 = await _0x1ae1bd[_0x113d29(0x145)]();
                _0x13008d = {
                    'title': _0x185b60[_0x113d29(0x123)][_0x113d29(0x128)],
                    'quality': _0x185b60[_0x113d29(0x123)][_0x113d29(0x129)]
                };
                let _0x4bc848 = {
                    'image': { 'url': _0x3a1e28 ? _0x113d29(0x132) : _0x69ed0a[0x0][_0x113d29(0x157)] },
                    'caption': _0x113d29(0x122) + _0x13008d[_0x113d29(0x128)] + _0x113d29(0x13d) + _0x13008d[_0x113d29(0x138)] + '\x0a' + (!_0x3a1e28 ? _0x113d29(0x13b) + _0x69ed0a[0x0][_0x113d29(0x154)] : '') + '\x0a' + (!_0x3a1e28 ? '│⿻\x20*Viewers:*\x20' + _0x69ed0a[0x0][_0x113d29(0x131)] : '') + '\x0a' + (!_0x3a1e28 ? '│⿻\x20*Uploaded:*\x20' + _0x69ed0a[0x0][_0x113d29(0x143)] : '') + '\x0a' + (!_0x3a1e28 ? '│⿻\x20*Artist:*\x20' + _0x69ed0a[0x0][_0x113d29(0x13f)]['name'] : '') + _0x113d29(0x13c) + _0x2663e5 + _0x113d29(0x153)
                };
                await _0x68b1a1[_0x113d29(0x144)](_0x1579ee[_0x113d29(0x12e)], _0x4bc848, { 'quoted': _0x1579ee }), await _0x68b1a1[_0x113d29(0x144)](_0x1579ee['from'], {
                    'document': _0x25e6f9,
                    'mimetype': _0x113d29(0x149),
                    'fileName': _0x69ed0a[0x0]['title'] + _0x113d29(0x14c),
                    'caption': _0x113d29(0x133),
                    'contextInfo': {
                        'externalAdReply': {
                            'showAdAttribution': ![],
                            'title': _0x13008d[_0x113d29(0x128)],
                            'body': _0x113d29(0x137),
                            'thumbnailUrl': _0x113d29(0x132),
                            'sourceUrl': _0x113d29(0x11e),
                            'mediaType': 0x1,
                            'renderLargerThumbnail': ![]
                        }
                    }
                }, { 'quoted': _0x1579ee }), await _0x1579ee[_0x113d29(0x148)]('✅'), await _0x1579ee[_0x113d29(0x150)]('Download\x20Success...\x0aSent\x20Document\x20Audio\x20Format\x20For:\x20*' + _0x13008d[_0x113d29(0x128)] + _0x113d29(0x13e) + _0x35755f + _0x113d29(0x12b));
            } else
                await _0x1579ee['reply']('Failed\x20to\x20download\x20audio.\x20Please\x20try\x20again\x20later.');
        } catch (_0xaa6d07) {
            console[_0x113d29(0x151)](_0x113d29(0x14f), _0xaa6d07), await _0x68b1a1[_0x113d29(0x144)](_0x1579ee['from'], { 'text': _0x113d29(0x136) });
        }
    }
};
export default Play;
