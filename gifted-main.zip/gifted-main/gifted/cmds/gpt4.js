(function (_0x56197c, _0x3ae667) {
    const _0x17c331 = _0xe77b, _0x413fbe = _0x56197c();
    while (!![]) {
        try {
            const _0x5d8fc8 = -parseInt(_0x17c331(0x193)) / 0x1 + parseInt(_0x17c331(0x184)) / 0x2 + -parseInt(_0x17c331(0x19d)) / 0x3 + -parseInt(_0x17c331(0x18b)) / 0x4 + parseInt(_0x17c331(0x183)) / 0x5 + -parseInt(_0x17c331(0x18f)) / 0x6 * (-parseInt(_0x17c331(0x1a5)) / 0x7) + -parseInt(_0x17c331(0x19c)) / 0x8 * (parseInt(_0x17c331(0x196)) / 0x9);
            if (_0x5d8fc8 === _0x3ae667)
                break;
            else
                _0x413fbe['push'](_0x413fbe['shift']());
        } catch (_0x1fa8c8) {
            _0x413fbe['push'](_0x413fbe['shift']());
        }
    }
}(_0x23e4, 0x79388));
import _0x21c6d5 from 'axios';
import _0x1b5c90, { prepareWAMessageMedia } from 'gifted-baileys';
function _0x23e4() {
    const _0x1c7a50 = [
        '📋\x20ᴄᴏᴘʏ\x20ᴡʜᴏʟᴇ\x20ᴛᴇxᴛ',
        'reply',
        '155813lIKIps',
        'chatgpt',
        'slice',
        'cta_copy',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l',
        'length',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ\x20ɢɪғᴛᴇᴅ',
        'Error\x20getting\x20response\x20from\x20GPT.',
        'push',
        'Hello\x20*_',
        'copy_code',
        'NativeFlowMessage',
        'gpt4ai',
        'split',
        'trim',
        'Invalid\x20response\x20from\x20the\x20GPT\x20API.',
        'InteractiveMessage',
        'message',
        '4077350BTSbwq',
        '1707258GfGYTH',
        'Footer',
        'gpt',
        'data',
        'cta_url',
        'chatgpt4v2',
        'pushName',
        '1412740qOllzE',
        'Header',
        'get',
        'Error\x20getting\x20GPT\x20response:',
        '66cvFdLY',
        'https://api.prabath-md.tech/api/gptv1?q=',
        'Body',
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Generating\x20Your\x20GPT4\x20Request...',
        '120523LhsYAw',
        '📋\x20ᴄᴏᴘʏ\x20ɢᴇɴᴇʀᴀᴛᴇᴅ\x20ᴄᴏᴅᴇ',
        'body',
        '195606hERhAS',
        'remoteJid',
        'key',
        'relayMessage',
        'create',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        '56uBheag',
        '2374746DqlzPf',
        'match',
        'stringify',
        '.menu',
        'Message',
        'React'
    ];
    _0x23e4 = function () {
        return _0x1c7a50;
    };
    return _0x23e4();
}
function _0xe77b(_0x435c58, _0x372e00) {
    const _0x23e439 = _0x23e4();
    return _0xe77b = function (_0xe77bfc, _0x3dd2b3) {
        _0xe77bfc = _0xe77bfc - 0x173;
        let _0x57de6b = _0x23e439[_0xe77bfc];
        return _0x57de6b;
    }, _0xe77b(_0x435c58, _0x372e00);
}
const {generateWAMessageFromContent, proto} = _0x1b5c90, gptResponse = async (_0x40f158, _0x100899) => {
        const _0x1dd874 = _0xe77b, _0x3df8c8 = _0x40f158['body'][_0x1dd874(0x19e)](/^[\\/!#.]/), _0x1a4953 = _0x3df8c8 ? _0x3df8c8[0x0] : '/', _0x5d414a = _0x40f158[_0x1dd874(0x195)]['startsWith'](_0x1a4953) ? _0x40f158[_0x1dd874(0x195)][_0x1dd874(0x1a7)](_0x1a4953[_0x1dd874(0x176)])[_0x1dd874(0x17e)]('\x20')[0x0]['toLowerCase']() : '', _0x2a59d8 = _0x40f158['body'][_0x1dd874(0x1a7)](_0x1a4953['length'] + _0x5d414a[_0x1dd874(0x176)])[_0x1dd874(0x17f)](), _0x496cc0 = [
                'chatgpt4',
                _0x1dd874(0x186),
                _0x1dd874(0x1a6),
                'gpt4v2',
                _0x1dd874(0x189),
                'gpt4',
                _0x1dd874(0x17d)
            ];
        if (_0x496cc0['includes'](_0x5d414a)) {
            if (!_0x2a59d8)
                return _0x40f158[_0x1dd874(0x1a4)](_0x1dd874(0x17a) + _0x40f158[_0x1dd874(0x18a)] + '_,*\x0a\x20I\x20am\x20Gifted\x20Premium\x20ChatGpt4.\x0a\x20Please\x20Ask\x20a\x20Question.');
            try {
                await _0x40f158['React']('🕘'), await _0x40f158[_0x1dd874(0x1a4)](_0x1dd874(0x192));
                const _0x124770 = _0x1dd874(0x190) + encodeURIComponent(_0x2a59d8), _0x2f6bd5 = await _0x21c6d5[_0x1dd874(0x18d)](_0x124770), _0x313635 = _0x2f6bd5['data'];
                if (_0x313635 && _0x313635[_0x1dd874(0x187)]) {
                    const _0x4ce9cb = _0x313635[_0x1dd874(0x187)], _0x1dbb01 = '' + _0x4ce9cb, _0x18f685 = _0x4ce9cb['match'](/```([\s\S]*?)```/);
                    let _0x498aac = [];
                    if (_0x18f685) {
                        const _0x123066 = _0x18f685[0x1];
                        _0x498aac[_0x1dd874(0x179)]({
                            'name': _0x1dd874(0x173),
                            'buttonParamsJson': JSON['stringify']({
                                'display_text': _0x1dd874(0x194),
                                'id': _0x1dd874(0x17b),
                                'copy_code': _0x123066
                            })
                        });
                    }
                    _0x498aac['push']({
                        'name': 'cta_copy',
                        'buttonParamsJson': JSON['stringify']({
                            'display_text': _0x1dd874(0x1a3),
                            'id': _0x1dd874(0x17b),
                            'copy_code': _0x1dbb01
                        })
                    }, {
                        'name': _0x1dd874(0x188),
                        'buttonParamsJson': JSON[_0x1dd874(0x19f)]({
                            'display_text': _0x1dd874(0x177),
                            'url': _0x1dd874(0x175)
                        })
                    }, {
                        'name': 'quick_reply',
                        'buttonParamsJson': JSON[_0x1dd874(0x19f)]({
                            'display_text': _0x1dd874(0x174),
                            'id': _0x1dd874(0x1a0)
                        })
                    });
                    let _0x3ec8f9 = generateWAMessageFromContent(_0x40f158['from'], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto['Message'][_0x1dd874(0x181)][_0x1dd874(0x19a)]({
                                    'body': proto[_0x1dd874(0x1a1)][_0x1dd874(0x181)][_0x1dd874(0x191)][_0x1dd874(0x19a)]({ 'text': _0x4ce9cb }),
                                    'footer': proto[_0x1dd874(0x1a1)]['InteractiveMessage'][_0x1dd874(0x185)][_0x1dd874(0x19a)]({ 'text': _0x1dd874(0x19b) }),
                                    'header': proto['Message'][_0x1dd874(0x181)][_0x1dd874(0x18c)][_0x1dd874(0x19a)]({
                                        'title': '',
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto['Message'][_0x1dd874(0x181)][_0x1dd874(0x17c)][_0x1dd874(0x19a)]({ 'buttons': _0x498aac })
                                })
                            }
                        }
                    }, {});
                    await _0x100899[_0x1dd874(0x199)](_0x3ec8f9[_0x1dd874(0x198)][_0x1dd874(0x197)], _0x3ec8f9[_0x1dd874(0x182)], { 'messageId': _0x3ec8f9[_0x1dd874(0x198)]['id'] }), await _0x40f158[_0x1dd874(0x1a2)]('✅');
                } else
                    throw new Error(_0x1dd874(0x180));
            } catch (_0x46aefb) {
                console['error'](_0x1dd874(0x18e), _0x46aefb[_0x1dd874(0x182)]), _0x40f158[_0x1dd874(0x1a4)](_0x1dd874(0x178)), await _0x40f158['React']('❌');
            }
        }
    };
export default gptResponse;
