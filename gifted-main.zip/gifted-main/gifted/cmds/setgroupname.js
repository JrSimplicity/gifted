function _0x14a6(_0x509e68, _0x17bdf6) {
    const _0x40ac3b = _0x40ac();
    return _0x14a6 = function (_0x14a6e3, _0x5c0988) {
        _0x14a6e3 = _0x14a6e3 - 0x18c;
        let _0x27c128 = _0x40ac3b[_0x14a6e3];
        return _0x27c128;
    }, _0x14a6(_0x509e68, _0x17bdf6);
}
(function (_0x5d5b3d, _0x2f89ba) {
    const _0x2f4581 = _0x14a6, _0x2ab869 = _0x5d5b3d();
    while (!![]) {
        try {
            const _0x2b1a29 = parseInt(_0x2f4581(0x1a7)) / 0x1 + -parseInt(_0x2f4581(0x1a9)) / 0x2 * (parseInt(_0x2f4581(0x18d)) / 0x3) + -parseInt(_0x2f4581(0x19f)) / 0x4 + parseInt(_0x2f4581(0x18f)) / 0x5 * (-parseInt(_0x2f4581(0x1ad)) / 0x6) + -parseInt(_0x2f4581(0x19b)) / 0x7 * (parseInt(_0x2f4581(0x1a5)) / 0x8) + parseInt(_0x2f4581(0x193)) / 0x9 + -parseInt(_0x2f4581(0x1a6)) / 0xa * (-parseInt(_0x2f4581(0x1ab)) / 0xb);
            if (_0x2b1a29 === _0x2f89ba)
                break;
            else
                _0x2ab869['push'](_0x2ab869['shift']());
        } catch (_0x1015b6) {
            _0x2ab869['push'](_0x2ab869['shift']());
        }
    }
}(_0x40ac, 0xc4358));
const setGroupName = async (_0x135545, _0x2c9f91) => {
    const _0x1fd017 = _0x14a6;
    try {
        const _0x550dd8 = await _0x2c9f91[_0x1fd017(0x18c)](_0x2c9f91['user']['id']), _0x12a8e5 = _0x135545[_0x1fd017(0x19e)][_0x1fd017(0x197)](/^[\\/!#.]/), _0x321918 = _0x12a8e5 ? _0x12a8e5[0x0] : '/', _0x14344a = _0x135545[_0x1fd017(0x19e)][_0x1fd017(0x19a)](_0x321918) ? _0x135545[_0x1fd017(0x19e)][_0x1fd017(0x198)](_0x321918[_0x1fd017(0x19c)])['split']('\x20')[0x0][_0x1fd017(0x1ac)]() : '', _0x33399e = _0x135545[_0x1fd017(0x19e)][_0x1fd017(0x198)](_0x321918[_0x1fd017(0x19c)] + _0x14344a['length'])[_0x1fd017(0x1af)](), _0x3921d3 = [
                _0x1fd017(0x190),
                _0x1fd017(0x192),
                _0x1fd017(0x199)
            ];
        if (!_0x3921d3[_0x1fd017(0x19d)](_0x14344a))
            return;
        if (!_0x135545[_0x1fd017(0x196)])
            return _0x135545[_0x1fd017(0x1ae)](_0x1fd017(0x1a1));
        const _0x3f78d6 = await _0x2c9f91['groupMetadata'](_0x135545['from']), _0x1a010c = _0x3f78d6[_0x1fd017(0x1aa)], _0x46dfc8 = _0x1a010c['find'](_0x27fb18 => _0x27fb18['id'] === _0x550dd8)?.['admin'], _0xc22adc = _0x1a010c[_0x1fd017(0x18e)](_0xd47531 => _0xd47531['id'] === _0x135545[_0x1fd017(0x1a4)])?.[_0x1fd017(0x1a3)];
        if (!_0x46dfc8)
            return _0x135545[_0x1fd017(0x1ae)](_0x1fd017(0x195));
        if (!_0xc22adc)
            return _0x135545[_0x1fd017(0x1ae)]('*📛\x20YOU\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*');
        if (!_0x33399e)
            return _0x135545['reply'](_0x1fd017(0x1a8));
        await _0x2c9f91[_0x1fd017(0x1a0)](_0x135545[_0x1fd017(0x1a2)], _0x33399e), _0x135545[_0x1fd017(0x1ae)]('Group\x20Name\x20Has\x20Been\x20Set\x20To:\x20' + _0x33399e);
    } catch (_0xe30fde) {
        console[_0x1fd017(0x194)]('Error:', _0xe30fde), _0x135545[_0x1fd017(0x1ae)](_0x1fd017(0x191));
    }
};
export default setGroupName;
function _0x40ac() {
    const _0x1f925c = [
        '69Hihbpq',
        'find',
        '128105CLCcGS',
        'setgroupname',
        'An\x20error\x20occurred\x20while\x20processing\x20the\x20command.',
        'gname',
        '3416607VtliTU',
        'error',
        '*📛\x20BOT\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*',
        'isGroup',
        'match',
        'slice',
        'setname',
        'startsWith',
        '14XfVFSt',
        'length',
        'includes',
        'body',
        '1528588fadhsz',
        'groupUpdateSubject',
        '*📛\x20THIS\x20COMMAND\x20CAN\x20ONLY\x20BE\x20USED\x20IN\x20GROUPS*',
        'from',
        'admin',
        'sender',
        '3447280voDSyy',
        '653170IBHaAf',
        '1311882Kdbved',
        '*📛\x20PLEASE\x20PROVIDE\x20A\x20NAME\x20TO\x20SET*',
        '134404Zwiwbl',
        'participants',
        '385YcNGjc',
        'toLowerCase',
        '90XSVqpB',
        'reply',
        'trim',
        'decodeJid'
    ];
    _0x40ac = function () {
        return _0x1f925c;
    };
    return _0x40ac();
}
