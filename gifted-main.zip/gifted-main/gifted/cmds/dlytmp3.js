(function (_0x375bc3, _0x392abb) {
    const _0x208239 = _0x9efb, _0x1ce140 = _0x375bc3();
    while (!![]) {
        try {
            const _0x59422f = -parseInt(_0x208239(0xce)) / 0x1 + -parseInt(_0x208239(0xc5)) / 0x2 + -parseInt(_0x208239(0xe3)) / 0x3 + parseInt(_0x208239(0xf6)) / 0x4 + parseInt(_0x208239(0xe2)) / 0x5 + -parseInt(_0x208239(0xf1)) / 0x6 + parseInt(_0x208239(0xfb)) / 0x7 * (parseInt(_0x208239(0xd6)) / 0x8);
            if (_0x59422f === _0x392abb)
                break;
            else
                _0x1ce140['push'](_0x1ce140['shift']());
        } catch (_0x3626e6) {
            _0x1ce140['push'](_0x1ce140['shift']());
        }
    }
}(_0x5b32, 0x84221));
function _0x5b32() {
    const _0x2fff26 = [
        'No\x20audios\x20found.',
        'buffer',
        '*_\x20,\x20Please\x20provide\x20the\x20song\x20name\x20or\x20YouTube\x20URL,\x20eg\x20*.ytmp3\x20Spectre\x20by\x20Alan\x20Walker*\x20or\x20*.ytmp3\x20https://www.youtube.com/watch?v=abc123*',
        '│⿻\x20*Uploaded:*\x20',
        '559677TMJAfN',
        '*\x20to\x20download\x20it\x20as\x20document\x20audio\x20format',
        'json',
        'views',
        'author',
        'slice',
        '*𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐒𝐎𝐍𝐆\x20𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑*\x0a\x0a╭───────────────◆\x0a│⿻\x20*Title:*\x20',
        '/api/download/ytmp3?url=',
        '8QzBzMB',
        'error',
        'includes',
        'body',
        'https://gifted-apis-third-30b2fdbb9819.herokuapp.com',
        'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l',
        'videos',
        '\x0a│⿻\x20*Quality:*\x20',
        'toLowerCase',
        '\x0a\x0a╭────────────────◆\x0a│\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*\x0a╰─────────────────◆',
        'download_url',
        'status',
        '2741090aQFYbx',
        '2190381QEaATi',
        'name',
        '&apikey=',
        'title',
        'ago',
        'test',
        '\x0a╰────────────────◆\x0a⦿\x20*Direct\x20Yt\x20Link:*\x20',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'https://telegra.ph/file/c2a4d8d65722553da4c89.jpg',
        'Download\x20Success...\x0aSent\x20Normal\x20Audio\x20Format\x20For:\x20*',
        'length',
        'timestamp',
        'trim',
        'from',
        '4271166japmnV',
        'reply',
        'play',
        'ytmp3',
        'sendMessage',
        '1052380KgMsDo',
        'success',
        'Failed\x20with\x20error\x20from\x20Gifted\x20API.\x20Please\x20try\x20again\x20later.',
        'thumbnail',
        'split',
        '18738671zoshnC',
        'match',
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Processing\x20from\x20GiftedAPi...',
        '1890768horPEt',
        'url',
        '│⿻\x20*Artist:*\x20',
        'result',
        'Failed\x20to\x20download\x20audio.\x20Please\x20try\x20again\x20later.'
    ];
    _0x5b32 = function () {
        return _0x2fff26;
    };
    return _0x5b32();
}
import _0x3a7977 from 'node-fetch';
import _0xb02f34 from 'yt-search';
function _0x9efb(_0x143b03, _0x460b29) {
    const _0x5b3252 = _0x5b32();
    return _0x9efb = function (_0x9efbf2, _0xfb3a17) {
        _0x9efbf2 = _0x9efbf2 - 0xc5;
        let _0x3d8158 = _0x5b3252[_0x9efbf2];
        return _0x3d8158;
    }, _0x9efb(_0x143b03, _0x460b29);
}
const Play = async (_0x4e4a81, _0x5a4b13) => {
    const _0x593fdb = _0x9efb, _0x4734ae = _0x4e4a81['body'][_0x593fdb(0xfc)](/^[\\/!#.]/), _0x3009ce = _0x4734ae ? _0x4734ae[0x0] : '/', _0x3e5dee = _0x593fdb(0xda), _0xaecda3 = 'giftedtechk', _0x1a0310 = _0x4e4a81['body']['startsWith'](_0x3009ce) ? _0x4e4a81[_0x593fdb(0xd9)]['slice'](_0x3009ce[_0x593fdb(0xed)])[_0x593fdb(0xfa)]('\x20')[0x0][_0x593fdb(0xde)]() : '', _0x7a6a59 = _0x4e4a81['body'][_0x593fdb(0xd3)](_0x3009ce[_0x593fdb(0xed)] + _0x1a0310[_0x593fdb(0xed)])[_0x593fdb(0xef)](), _0x5d5240 = [
            _0x593fdb(0xf3),
            _0x593fdb(0xf4),
            'yta'
        ];
    if (_0x5d5240[_0x593fdb(0xd8)](_0x1a0310)) {
        if (!_0x7a6a59) {
            await _0x4e4a81['reply']('Hello\x20_*' + _0x4e4a81['pushName'] + _0x593fdb(0xcc));
            return;
        }
        try {
            await _0x4e4a81['React']('🕘'), await _0x4e4a81[_0x593fdb(0xf2)](_0x593fdb(0xfd));
            let _0xf66fc6 = _0x7a6a59, _0x23c446 = [], _0x81de5d = {};
            const _0x589b6a = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/, _0x23189c = _0x589b6a[_0x593fdb(0xe8)](_0x7a6a59);
            if (!_0x23189c) {
                const _0x40d65b = await _0xb02f34(_0x7a6a59);
                _0x23c446 = _0x40d65b[_0x593fdb(0xdc)];
                if (_0x23c446 && _0x23c446[_0x593fdb(0xed)] > 0x0 && _0x23c446[0x0])
                    _0xf66fc6 = _0x23c446[0x0][_0x593fdb(0xc6)];
                else {
                    await _0x4e4a81['reply'](_0x593fdb(0xca));
                    return;
                }
            }
            const _0xba0657 = await _0x3a7977(_0x3e5dee + _0x593fdb(0xd5) + encodeURIComponent(_0xf66fc6) + _0x593fdb(0xe5) + _0xaecda3), _0x1edb1f = await _0xba0657[_0x593fdb(0xd0)]();
            if (_0x1edb1f[_0x593fdb(0xe1)] === 0xc8 && _0x1edb1f[_0x593fdb(0xf7)]) {
                const _0x52080e = _0x1edb1f[_0x593fdb(0xc8)][_0x593fdb(0xe0)], _0x1e313b = await _0x3a7977(_0x52080e), _0x52422c = await _0x1e313b[_0x593fdb(0xcb)]();
                _0x81de5d = {
                    'title': _0x1edb1f['result'][_0x593fdb(0xe6)],
                    'quality': _0x1edb1f[_0x593fdb(0xc8)]['type']
                };
                let _0x4f87fe = {
                    'image': { 'url': _0x23189c ? _0x593fdb(0xeb) : _0x23c446[0x0][_0x593fdb(0xf9)] },
                    'caption': _0x593fdb(0xd4) + _0x81de5d[_0x593fdb(0xe6)] + _0x593fdb(0xdd) + _0x81de5d['quality'] + '\x0a' + (!_0x23189c ? '│⿻\x20*Duration:*\x20' + _0x23c446[0x0][_0x593fdb(0xee)] : '') + '\x0a' + (!_0x23189c ? '│⿻\x20*Viewers:*\x20' + _0x23c446[0x0][_0x593fdb(0xd1)] : '') + '\x0a' + (!_0x23189c ? _0x593fdb(0xcd) + _0x23c446[0x0][_0x593fdb(0xe7)] : '') + '\x0a' + (!_0x23189c ? _0x593fdb(0xc7) + _0x23c446[0x0][_0x593fdb(0xd2)][_0x593fdb(0xe4)] : '') + _0x593fdb(0xe9) + _0xf66fc6 + _0x593fdb(0xdf)
                };
                await _0x5a4b13[_0x593fdb(0xf5)](_0x4e4a81[_0x593fdb(0xf0)], _0x4f87fe, { 'quoted': _0x4e4a81 }), await _0x5a4b13[_0x593fdb(0xf5)](_0x4e4a81[_0x593fdb(0xf0)], {
                    'audio': _0x52422c,
                    'mimetype': 'audio/mp4',
                    'caption': _0x593fdb(0xea),
                    'contextInfo': {
                        'externalAdReply': {
                            'showAdAttribution': ![],
                            'title': _0x81de5d[_0x593fdb(0xe6)],
                            'body': 'Powered\x20by\x20Gifted\x20Tech',
                            'thumbnailUrl': _0x593fdb(0xeb),
                            'sourceUrl': _0x593fdb(0xdb),
                            'mediaType': 0x1,
                            'renderLargerThumbnail': ![]
                        }
                    }
                }, { 'quoted': _0x4e4a81 }), await _0x4e4a81['React']('✅'), await _0x4e4a81[_0x593fdb(0xf2)](_0x593fdb(0xec) + _0x81de5d[_0x593fdb(0xe6)] + '*\x0aUse\x20*.song\x20' + _0x7a6a59 + _0x593fdb(0xcf));
            } else
                await _0x4e4a81[_0x593fdb(0xf2)](_0x593fdb(0xc9));
        } catch (_0x393f65) {
            console[_0x593fdb(0xd7)]('Error\x20from\x20Gifted\x20API:', _0x393f65), await _0x5a4b13[_0x593fdb(0xf5)](_0x4e4a81[_0x593fdb(0xf0)], { 'text': _0x593fdb(0xf8) });
        }
    }
};
export default Play;
