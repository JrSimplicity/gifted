const _0x587771 = _0x26be;
(function (_0x2f69e8, _0x93a962) {
    const _0x4ea636 = _0x26be, _0x5547a0 = _0x2f69e8();
    while (!![]) {
        try {
            const _0x52ec58 = parseInt(_0x4ea636(0x1ae)) / (0x18a * -0x11 + -0x6f * 0x39 + 0x32e2) * (-parseInt(_0x4ea636(0x1ca)) / (-0x62c + -0x10fa + -0x2e5 * -0x8)) + parseInt(_0x4ea636(0x1ba)) / (-0x8 * -0x347 + -0x6ff + 0x1 * -0x1336) + parseInt(_0x4ea636(0x19d)) / (-0x1225 + 0x1d77 * 0x1 + -0xb4e) + -parseInt(_0x4ea636(0x18c)) / (0x23ad + -0x3a4 * -0x5 + -0x47d * 0xc) + -parseInt(_0x4ea636(0x1dd)) / (-0x1 * -0x1b2f + 0x14b * -0x9 + -0xf86) + parseInt(_0x4ea636(0x190)) / (0x73 * -0x3d + 0x15c2 + 0x2 * 0x2d6) * (parseInt(_0x4ea636(0x194)) / (-0x13 * -0x72 + 0xe * 0x70 + -0x9 * 0x19e)) + parseInt(_0x4ea636(0x1d3)) / (-0x49 * 0x3f + -0x9f + 0x129f);
            if (_0x52ec58 === _0x93a962)
                break;
            else
                _0x5547a0['push'](_0x5547a0['shift']());
        } catch (_0x500ee6) {
            _0x5547a0['push'](_0x5547a0['shift']());
        }
    }
}(_0x1853, 0x6b * 0x963 + 0x43e19 * 0x1 + -0x5914d));
function _0x26be(_0x2aaa87, _0x537f7e) {
    const _0x5a7ca9 = _0x1853();
    return _0x26be = function (_0x43c114, _0x387924) {
        _0x43c114 = _0x43c114 - (-0x715 + 0x142e + -0xb96 * 0x1);
        let _0x5e01ed = _0x5a7ca9[_0x43c114];
        return _0x5e01ed;
    }, _0x26be(_0x2aaa87, _0x537f7e);
}
import _0x37e671, { prepareWAMessageMedia } from 'gifted-baileys';
function _0x1853() {
    const _0x46cb9f = [
        'fnBzr',
        'eMessage',
        '815340CAowrp',
        'remoteJid',
        '.repo',
        '\x20Minute(s)',
        'ZxjEn',
        '══════════',
        'D\x20MD\x20IS\x20RU',
        '*\x0a*┃❍\x20',
        'rSxGl',
        'key',
        '\x20Day(s)*\x0a*',
        '┃❍\x20',
        'ewsletter',
        'i1l',
        'TLIoh',
        '_*\x0a\x0a*GIFTE',
        '\x0a*╭═══════',
        '1IBIiTH',
        'WLFLx',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ',
        '/channel/0',
        'vqMVE',
        'WasfL',
        '\x0a*Hello\x20_',
        'https://wh',
        'repeat',
        '.test',
        '029VaYauR9',
        'ᴛᴇsᴛ\x20ᴍᴇssᴀ',
        '259830Yyjptf',
        'BCBCc',
        'alive',
        'ʙᴏᴛ\x20sᴄʀɪᴘᴛ',
        '\x20Second(s)',
        'atsapp.com',
        'fromCharCo',
        'Footer',
        'Header',
        'slice',
        'NativeFlow',
        'relayMessa',
        'Interactiv',
        'uptime',
        '𝟓*',
        '\x20INFO:*\x20',
        '201706auXvLc',
        'toLowerCas',
        '═⊷*\x0a',
        'BOT\x20UPTIME',
        '60769123@n',
        'includes',
        'stringify',
        'Body',
        '.menu',
        '3594339aXJUgL',
        'xirBq',
        'floor',
        'dqXwq',
        'cta_url',
        'Gifted-MD',
        '⊷*\x0a*┃❍\x20',
        'length',
        'quSnn',
        'NNING!!*\x0a*',
        '1183212nQuIpb',
        'pushName',
        'message',
        'tsIVn',
        '1203632499',
        'test',
        'match',
        'create',
        'EwxDi',
        'from',
        'body',
        '𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕',
        '\x20ɢɪғᴛᴇᴅ',
        'sender',
        'quick_repl',
        '1162855TuQlcm',
        '\x20Hour(s)*\x0a',
        '*┃❍\x20',
        'Message',
        '11095FNUAQB',
        'ahUhx',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        'QgXCB',
        '56fgGFGT',
        'ISTkHTj4xv',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆',
        'FtSNz',
        'startsWith',
        '*\x0a*╰══════',
        'ovjSV'
    ];
    _0x1853 = function () {
        return _0x46cb9f;
    };
    return _0x1853();
}
const {generateWAMessageFromContent, proto} = _0x37e671, more = String[_0x587771(0x1c0) + 'de'](-0x1 * 0x2e89 + 0x73c + -0x1 * -0x475b), readmore = more[_0x587771(0x1b6)](0x27 * -0xe2 + 0x20e + 0x3001), alive = async (_0x5e2f54, _0x304ace) => {
        const _0x81829d = _0x587771, _0x1d6bf7 = {
                'WLFLx': function (_0x43e46b, _0xbf8560) {
                    return _0x43e46b / _0xbf8560;
                },
                'dqXwq': function (_0x5f332c, _0x362067) {
                    return _0x5f332c * _0x362067;
                },
                'ZxjEn': function (_0x34c3e0, _0x5cb125) {
                    return _0x34c3e0 % _0x5cb125;
                },
                'xirBq': function (_0x4b2160, _0x14a0dd) {
                    return _0x4b2160 % _0x14a0dd;
                },
                'vqMVE': function (_0x4a6d43, _0x5970d7) {
                    return _0x4a6d43 % _0x5970d7;
                },
                'quSnn': _0x81829d(0x1c7),
                'BCBCc': _0x81829d(0x1bc),
                'WasfL': _0x81829d(0x18b) + 'y',
                'EwxDi': _0x81829d(0x1bd),
                'QgXCB': _0x81829d(0x192),
                'TLIoh': _0x81829d(0x1b9) + 'ɢᴇ',
                'rSxGl': _0x81829d(0x1d7),
                'ovjSV': _0x81829d(0x1b0) + _0x81829d(0x189),
                'tsIVn': function (_0x3da3c8, _0x443fad, _0x2192bd, _0x448267) {
                    return _0x3da3c8(_0x443fad, _0x2192bd, _0x448267);
                },
                'ahUhx': _0x81829d(0x196) + _0x81829d(0x188) + _0x81829d(0x1c8),
                'FtSNz': _0x81829d(0x1e1) + _0x81829d(0x1ce) + _0x81829d(0x1a9),
                'fnBzr': _0x81829d(0x1d8)
            }, _0x176af0 = process[_0x81829d(0x1c7)](), _0x5c0e31 = Math[_0x81829d(0x1d5)](_0x1d6bf7[_0x81829d(0x1af)](_0x176af0, _0x1d6bf7[_0x81829d(0x1d6)](-0x1bb * -0x10 + 0x31c * 0x7 + 0x9 * -0x57c, -0xeac + 0x21c8 + -0x11 * 0x4c))), _0x10063a = Math[_0x81829d(0x1d5)](_0x1d6bf7[_0x81829d(0x1af)](_0x1d6bf7[_0x81829d(0x1a1)](_0x176af0, _0x1d6bf7[_0x81829d(0x1d6)](0x1563 + -0x214c + 0xc01, -0x1 * -0x916 + -0x1640 + 0x1b3a)), -0x7e3 + 0x2 * -0x12cd + -0xbe9 * -0x5)), _0x518bef = Math[_0x81829d(0x1d5)](_0x1d6bf7[_0x81829d(0x1af)](_0x1d6bf7[_0x81829d(0x1d4)](_0x176af0, -0xd36 * 0x1 + -0x7ff + 0x2345), -0x295 * 0xb + 0x26 * -0x8f + 0x31dd)), _0x2f74aa = Math[_0x81829d(0x1d5)](_0x1d6bf7[_0x81829d(0x1b2)](_0x176af0, 0x1 * 0x9eb + 0x642 * -0x1 + 0x1 * -0x36d)), _0x35cc6f = /^[\\/!#.]/gi[_0x81829d(0x1e2)](_0x5e2f54[_0x81829d(0x187)]) ? _0x5e2f54[_0x81829d(0x187)][_0x81829d(0x183)](/^[\\/!#.]/gi)[-0xe33 + 0x1646 + 0x2b1 * -0x3] : '/', _0x30a775 = _0x5e2f54[_0x81829d(0x187)][_0x81829d(0x198)](_0x35cc6f) ? _0x5e2f54[_0x81829d(0x187)][_0x81829d(0x1c3)](_0x35cc6f[_0x81829d(0x1da)])[_0x81829d(0x1cb) + 'e']() : '';
        if ([
                _0x1d6bf7[_0x81829d(0x1db)],
                _0x1d6bf7[_0x81829d(0x1bb)]
            ][_0x81829d(0x1cf)](_0x30a775)) {
            const _0x364ba5 = _0x81829d(0x1b4) + _0x5e2f54[_0x81829d(0x1de)] + (_0x81829d(0x1ac) + _0x81829d(0x1a3) + _0x81829d(0x1dc) + _0x81829d(0x1cd) + _0x81829d(0x1c9)) + readmore + (_0x81829d(0x1ad) + _0x81829d(0x1a2) + _0x81829d(0x1d9)) + _0x5c0e31 + (_0x81829d(0x1a7) + _0x81829d(0x1a8)) + _0x10063a + (_0x81829d(0x18d) + _0x81829d(0x18e)) + _0x518bef + (_0x81829d(0x1a0) + _0x81829d(0x1a4)) + _0x2f74aa + (_0x81829d(0x1be) + _0x81829d(0x199) + _0x81829d(0x1a2) + _0x81829d(0x1cc)), _0x5abd33 = [
                    {
                        'name': _0x1d6bf7[_0x81829d(0x1b3)],
                        'buttonParamsJson': JSON[_0x81829d(0x1d0)]({
                            'display_text': _0x1d6bf7[_0x81829d(0x185)],
                            'id': _0x81829d(0x19f)
                        })
                    },
                    {
                        'name': _0x1d6bf7[_0x81829d(0x1b3)],
                        'buttonParamsJson': JSON[_0x81829d(0x1d0)]({
                            'display_text': _0x1d6bf7[_0x81829d(0x193)],
                            'id': _0x81829d(0x1d2)
                        })
                    },
                    {
                        'name': _0x1d6bf7[_0x81829d(0x1b3)],
                        'buttonParamsJson': JSON[_0x81829d(0x1d0)]({
                            'display_text': _0x1d6bf7[_0x81829d(0x1ab)],
                            'id': _0x81829d(0x1b7)
                        })
                    },
                    {
                        'name': _0x1d6bf7[_0x81829d(0x1a5)],
                        'buttonParamsJson': JSON[_0x81829d(0x1d0)]({
                            'display_text': _0x1d6bf7[_0x81829d(0x19a)],
                            'url': _0x81829d(0x1b5) + _0x81829d(0x1bf) + _0x81829d(0x1b1) + _0x81829d(0x1b8) + _0x81829d(0x195) + _0x81829d(0x1aa)
                        })
                    }
                ], _0x5d3811 = _0x1d6bf7[_0x81829d(0x1e0)](generateWAMessageFromContent, _0x5e2f54[_0x81829d(0x186)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x81829d(0x18f)][_0x81829d(0x1c6) + _0x81829d(0x19c)][_0x81829d(0x184)]({
                                'body': proto[_0x81829d(0x18f)][_0x81829d(0x1c6) + _0x81829d(0x19c)][_0x81829d(0x1d1)][_0x81829d(0x184)]({ 'text': _0x364ba5 }),
                                'footer': proto[_0x81829d(0x18f)][_0x81829d(0x1c6) + _0x81829d(0x19c)][_0x81829d(0x1c1)][_0x81829d(0x184)]({ 'text': _0x1d6bf7[_0x81829d(0x191)] }),
                                'header': proto[_0x81829d(0x18f)][_0x81829d(0x1c6) + _0x81829d(0x19c)][_0x81829d(0x1c2)][_0x81829d(0x184)]({
                                    'title': '',
                                    'gifPlayback': !![],
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto[_0x81829d(0x18f)][_0x81829d(0x1c6) + _0x81829d(0x19c)][_0x81829d(0x1c4) + _0x81829d(0x18f)][_0x81829d(0x184)]({ 'buttons': _0x5abd33 }),
                                'contextInfo': {
                                    'mentionedJid': [_0x5e2f54[_0x81829d(0x18a)]],
                                    'forwardingScore': 0x3e7,
                                    'isForwarded': ![],
                                    'forwardedNewsletterMessageInfo': {
                                        'newsletterJid': _0x1d6bf7[_0x81829d(0x197)],
                                        'newsletterName': _0x1d6bf7[_0x81829d(0x19b)],
                                        'serverMessageId': 0x8f
                                    }
                                }
                            })
                        }
                    }
                }, {});
            await _0x304ace[_0x81829d(0x1c5) + 'ge'](_0x5d3811[_0x81829d(0x1a6)][_0x81829d(0x19e)], _0x5d3811[_0x81829d(0x1df)], { 'messageId': _0x5d3811[_0x81829d(0x1a6)]['id'] });
        }
    };
export default alive;
