function _0x4173() {
    const _0x242eaa = [
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆',
        '1691764fyQCdv',
        'https://ap',
        'startsWith',
        '4?text=',
        'message',
        '380570XRfCeM',
        'ywsdE',
        '17412957RSgusf',
        'ExeZW',
        '207048qHkcVt',
        'relayMessa',
        'error',
        '𝟓*',
        'Code',
        'NativeFlow',
        'detNA',
        'ing\x20GPT\x20re',
        'eaoPf',
        'split',
        'create',
        'Hello\x20*_',
        'copy_code',
        'ncrypted\x20t',
        'includes',
        'cta_copy',
        'length',
        'i.maskser.',
        '279765IuIQsM',
        'rypt.',
        'ls/debase6',
        'Interactiv',
        '_,*\x0a\x20Provi',
        'React',
        'body',
        'Yivhe',
        'result',
        'lpDZw',
        'm\x20the\x20GPT\x20',
        'FbDmK',
        'Body',
        '2NauwwQ',
        'Error\x20gett',
        'get',
        'Message',
        'ext\x20to\x20dec',
        'stringify',
        'key',
        'Copy\x20Your\x20',
        'A\x20moment,.',
        '217rPoltc',
        'Invalid\x20re',
        '1088558ExDysq',
        'trim',
        '6rkLPgy',
        '8ePQKQn',
        'AsvDh',
        '17443632fvadqG',
        'DcUrh',
        'debase',
        '407NGRKsr',
        'ing\x20respon',
        'pushName',
        'me/api/too',
        'remoteJid',
        'eMessage',
        'reply',
        'UYJTq',
        'from',
        'sponse\x20fro',
        'sendMessag',
        '𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕',
        'Header',
        'toLowerCas',
        'slice',
        'data',
        'evdoX',
        'sponse:',
        'API.',
        'gtCDJ',
        'Footer',
        'de\x20Me\x20an\x20e',
        'se\x20from\x20GP',
        'match'
    ];
    _0x4173 = function () {
        return _0x242eaa;
    };
    return _0x4173();
}
(function (_0x58b452, _0x9f8911) {
    const _0x58e272 = _0x50c8, _0x149c0f = _0x58b452();
    while (!![]) {
        try {
            const _0x39e037 = -parseInt(_0x58e272(0xf3)) / (-0x7 * 0x327 + 0x1616 + -0x4) * (parseInt(_0x58e272(0xfe)) / (0x322 * 0x2 + 0x21aa * 0x1 + -0x27ec)) + parseInt(_0x58e272(0x100)) / (0x1 * 0xc6e + 0x8e2 * -0x3 + 0x1 * 0xe3b) * (-parseInt(_0x58e272(0xcb)) / (-0x263 + 0x15c1 * 0x1 + -0x135a)) + -parseInt(_0x58e272(0xe6)) / (0x749 * -0x3 + -0x911 * 0x1 + 0x59 * 0x59) + -parseInt(_0x58e272(0xd4)) / (0x23b5 + 0x1 * 0x1181 + 0x353 * -0x10) * (-parseInt(_0x58e272(0xfc)) / (-0x1a1 + 0x1 * -0x4ab + 0x653)) + parseInt(_0x58e272(0x101)) / (0xe57 * -0x2 + -0xbce * 0x2 + -0x4a * -0xb5) * (parseInt(_0x58e272(0xd2)) / (0x2 * 0xd00 + 0x1 * 0x239f + -0x3d96)) + -parseInt(_0x58e272(0xd0)) / (0x1dda + 0x1fa5 * -0x1 + 0x1 * 0x1d5) * (-parseInt(_0x58e272(0x106)) / (0x165c + 0xb * -0xc7 + -0xdc4)) + -parseInt(_0x58e272(0x103)) / (0x105 * 0x1d + 0x267b * -0x1 + 0x8f6);
            if (_0x39e037 === _0x9f8911)
                break;
            else
                _0x149c0f['push'](_0x149c0f['shift']());
        } catch (_0xd1fb51) {
            _0x149c0f['push'](_0x149c0f['shift']());
        }
    }
}(_0x4173, 0x10fb9f + 0x1 * 0x12c045 + -0x14f44b));
function _0x50c8(_0x500363, _0x3c658f) {
    const _0x5e3edd = _0x4173();
    return _0x50c8 = function (_0x24c661, _0x4eec7d) {
        _0x24c661 = _0x24c661 - (-0xec1 * 0x1 + 0x21ce + -0x1254);
        let _0x242601 = _0x5e3edd[_0x24c661];
        return _0x242601;
    }, _0x50c8(_0x500363, _0x3c658f);
}
import _0x1704a2 from 'axios';
import _0x541df1, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x541df1, DEbase = async (_0x2c016c, _0x19fcaf) => {
        const _0x196863 = _0x50c8, _0xc3c0d4 = {
                'FbDmK': function (_0x50f315, _0x5d49d4) {
                    return _0x50f315 + _0x5d49d4;
                },
                'eaoPf': _0x196863(0x105),
                'gtCDJ': _0x196863(0xfb) + '..',
                'Yivhe': function (_0xccdf43, _0x236434) {
                    return _0xccdf43(_0x236434);
                },
                'detNA': function (_0x4bae68, _0x19a853, _0x295ca1, _0x236ca6) {
                    return _0x4bae68(_0x19a853, _0x295ca1, _0x236ca6);
                },
                'DcUrh': _0x196863(0xca) + _0x196863(0xbd) + _0x196863(0xd7),
                'ExeZW': _0x196863(0xe3),
                'ywsdE': _0x196863(0xfa) + _0x196863(0xd8),
                'lpDZw': _0x196863(0xe0),
                'evdoX': _0x196863(0xfd) + _0x196863(0xbb) + _0x196863(0xf0) + _0x196863(0xc4),
                'AsvDh': _0x196863(0xf4) + _0x196863(0xdb) + _0x196863(0xc3),
                'UYJTq': _0x196863(0xf4) + _0x196863(0x107) + _0x196863(0xc8) + 'T.'
            }, _0x351fa7 = _0x2c016c[_0x196863(0xec)][_0x196863(0xc9)](/^[\\/!#.]/), _0x2710e7 = _0x351fa7 ? _0x351fa7[-0x16a * -0x11 + 0xe32 + 0x131e * -0x2] : '/', _0x1b2a2b = _0x2c016c[_0x196863(0xec)][_0x196863(0xcd)](_0x2710e7) ? _0x2c016c[_0x196863(0xec)][_0x196863(0xc0)](_0x2710e7[_0x196863(0xe4)])[_0x196863(0xdd)]('\x20')[-0x1bb1 + -0xfe2 + -0x61 * -0x73][_0x196863(0xbf) + 'e']() : '', _0x1ed349 = _0x2c016c[_0x196863(0xec)][_0x196863(0xc0)](_0xc3c0d4[_0x196863(0xf1)](_0x2710e7[_0x196863(0xe4)], _0x1b2a2b[_0x196863(0xe4)]))[_0x196863(0xff)](), _0x2fbe78 = [_0xc3c0d4[_0x196863(0xdc)]];
        if (_0x2fbe78[_0x196863(0xe2)](_0x1b2a2b)) {
            if (!_0x1ed349)
                return _0x2c016c[_0x196863(0x10c)](_0x196863(0xdf) + _0x2c016c[_0x196863(0x108)] + (_0x196863(0xea) + _0x196863(0xc7) + _0x196863(0xe1) + _0x196863(0xf7) + _0x196863(0xe7)));
            try {
                await _0x2c016c[_0x196863(0xeb)]('🕘'), await _0x2c016c[_0x196863(0x10c)](_0xc3c0d4[_0x196863(0xc5)]);
                const _0x237caf = _0x196863(0xcc) + _0x196863(0xe5) + _0x196863(0x109) + _0x196863(0xe8) + _0x196863(0xce) + _0xc3c0d4[_0x196863(0xed)](encodeURIComponent, _0x1ed349), _0x25a1a0 = await _0x1704a2[_0x196863(0xf5)](_0x237caf), _0x557239 = _0x25a1a0[_0x196863(0xc1)];
                if (_0x557239 && _0x557239[_0x196863(0xee)]) {
                    const _0x4c36ab = _0x557239[_0x196863(0xee)], _0x8f42aa = _0x4c36ab[_0x196863(0xc9)](/```([\s\S]*?)```/);
                    if (_0x8f42aa) {
                        const _0x5d3897 = _0x8f42aa[-0x535 * 0x1 + 0x1115 * 0x2 + -0x44 * 0x6d];
                        let _0x99ed84 = _0xc3c0d4[_0x196863(0xda)](generateWAMessageFromContent, _0x2c016c[_0x196863(0xba)], {
                            'viewOnceMessage': {
                                'message': {
                                    'messageContextInfo': {
                                        'deviceListMetadata': {},
                                        'deviceListMetadataVersion': 0x2
                                    },
                                    'interactiveMessage': proto[_0x196863(0xf6)][_0x196863(0xe9) + _0x196863(0x10b)][_0x196863(0xde)]({
                                        'body': proto[_0x196863(0xf6)][_0x196863(0xe9) + _0x196863(0x10b)][_0x196863(0xf2)][_0x196863(0xde)]({ 'text': _0x4c36ab }),
                                        'footer': proto[_0x196863(0xf6)][_0x196863(0xe9) + _0x196863(0x10b)][_0x196863(0xc6)][_0x196863(0xde)]({ 'text': _0xc3c0d4[_0x196863(0x104)] }),
                                        'header': proto[_0x196863(0xf6)][_0x196863(0xe9) + _0x196863(0x10b)][_0x196863(0xbe)][_0x196863(0xde)]({
                                            'title': '',
                                            'subtitle': '',
                                            'hasMediaAttachment': ![]
                                        }),
                                        'nativeFlowMessage': proto[_0x196863(0xf6)][_0x196863(0xe9) + _0x196863(0x10b)][_0x196863(0xd9) + _0x196863(0xf6)][_0x196863(0xde)]({
                                            'buttons': [{
                                                    'name': _0xc3c0d4[_0x196863(0xd3)],
                                                    'buttonParamsJson': JSON[_0x196863(0xf8)]({
                                                        'display_text': _0xc3c0d4[_0x196863(0xd1)],
                                                        'id': _0xc3c0d4[_0x196863(0xef)],
                                                        'copy_code': _0x5d3897
                                                    })
                                                }]
                                        })
                                    })
                                }
                            }
                        }, {});
                        await _0x19fcaf[_0x196863(0xd5) + 'ge'](_0x99ed84[_0x196863(0xf9)][_0x196863(0x10a)], _0x99ed84[_0x196863(0xcf)], { 'messageId': _0x99ed84[_0x196863(0xf9)]['id'] });
                    } else
                        await _0x19fcaf[_0x196863(0xbc) + 'e'](_0x2c016c[_0x196863(0xba)], { 'text': _0x4c36ab }, { 'quoted': _0x2c016c });
                    await _0x2c016c[_0x196863(0xeb)]('✅');
                } else
                    throw new Error(_0xc3c0d4[_0x196863(0xc2)]);
            } catch (_0xe8e735) {
                console[_0x196863(0xd6)](_0xc3c0d4[_0x196863(0x102)], _0xe8e735[_0x196863(0xcf)]), _0x2c016c[_0x196863(0x10c)](_0xc3c0d4[_0x196863(0xb9)]), await _0x2c016c[_0x196863(0xeb)]('❌');
            }
        }
    };
export default DEbase;
