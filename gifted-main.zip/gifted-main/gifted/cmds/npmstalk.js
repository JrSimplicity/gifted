function _0xeeb8() {
    const _0x4918ed = [
        '_,*\x0a\x20Please\x20provide\x20an\x20npm\x20package\x20name\x20after\x20the\x20command\x20ie\x20*.npm\x20axios*',
        'length',
        'sendMessage',
        'trim',
        'split',
        'includes',
        '\x0a\x0a>\x20©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓',
        'npm',
        'startsWith',
        'message',
        '1650dLlsxw',
        '2745NwUMgF',
        '\x0a*Download\x20Link:*\x20',
        'slice',
        '\x0a*License:*\x20',
        'reply',
        '*Name:*\x20',
        '4371773fMiQMO',
        '*Published:*\x20',
        'Hello\x20*_',
        'toLowerCase',
        'React',
        '58mYdQoa',
        'Invalid\x20response\x20from\x20the\x20Gifted\x20API.',
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Generating\x20Your\x20NpmStalk\x20Request...',
        '*Readme:*\x20',
        'pushName',
        '*Package\x20Link:*\x20',
        '\x0a*Owner:*\x20',
        '88096gEpGyd',
        '217530txUOTF',
        '2557293yoYZCD',
        '2960jFoNMK',
        'data',
        '*Homepage:*\x20',
        '23334xKKBhx',
        '270gBEjYr',
        'body',
        'get',
        'npmstalk',
        'match',
        'N/A',
        '6721896fqeooL'
    ];
    _0xeeb8 = function () {
        return _0x4918ed;
    };
    return _0xeeb8();
}
(function (_0x33c7bb, _0x39475e) {
    const _0x2c2bbd = _0x27bb, _0x30b4a2 = _0x33c7bb();
    while (!![]) {
        try {
            const _0x26a1e7 = parseInt(_0x2c2bbd(0x16c)) / 0x1 * (parseInt(_0x2c2bbd(0x14e)) / 0x2) + -parseInt(_0x2c2bbd(0x14a)) / 0x3 + parseInt(_0x2c2bbd(0x14b)) / 0x4 * (-parseInt(_0x2c2bbd(0x161)) / 0x5) + -parseInt(_0x2c2bbd(0x155)) / 0x6 + -parseInt(_0x2c2bbd(0x167)) / 0x7 + parseInt(_0x2c2bbd(0x173)) / 0x8 * (-parseInt(_0x2c2bbd(0x14f)) / 0x9) + -parseInt(_0x2c2bbd(0x174)) / 0xa * (-parseInt(_0x2c2bbd(0x160)) / 0xb);
            if (_0x26a1e7 === _0x39475e)
                break;
            else
                _0x30b4a2['push'](_0x30b4a2['shift']());
        } catch (_0x39aab8) {
            _0x30b4a2['push'](_0x30b4a2['shift']());
        }
    }
}(_0xeeb8, 0x93e22));
import _0x4099c2 from 'axios';
import _0x270584, { prepareWAMessageMedia } from 'gifted-baileys';
function _0x27bb(_0x185d71, _0x864876) {
    const _0xeeb8f3 = _0xeeb8();
    return _0x27bb = function (_0x27bbe7, _0x28955c) {
        _0x27bbe7 = _0x27bbe7 - 0x14a;
        let _0x47d577 = _0xeeb8f3[_0x27bbe7];
        return _0x47d577;
    }, _0x27bb(_0x185d71, _0x864876);
}
const {generateWAMessageFromContent, proto} = _0x270584, npmstalk = async (_0x5593ed, _0x241c7c) => {
        const _0x45c787 = _0x27bb, _0x50cfe0 = _0x5593ed['body'][_0x45c787(0x153)](/^[\\/!#.]/), _0x29f413 = _0x50cfe0 ? _0x50cfe0[0x0] : '/', _0x27fab6 = _0x5593ed[_0x45c787(0x150)][_0x45c787(0x15e)](_0x29f413) ? _0x5593ed[_0x45c787(0x150)][_0x45c787(0x163)](_0x29f413[_0x45c787(0x157)])[_0x45c787(0x15a)]('\x20')[0x0][_0x45c787(0x16a)]() : '', _0xb888b5 = _0x5593ed['body'][_0x45c787(0x163)](_0x29f413[_0x45c787(0x157)] + _0x27fab6[_0x45c787(0x157)])[_0x45c787(0x159)](), _0x46cece = [
                _0x45c787(0x15d),
                _0x45c787(0x152)
            ];
        if (_0x46cece[_0x45c787(0x15b)](_0x27fab6)) {
            if (!_0xb888b5)
                return _0x5593ed[_0x45c787(0x165)](_0x45c787(0x169) + _0x5593ed[_0x45c787(0x170)] + _0x45c787(0x156));
            try {
                await _0x5593ed[_0x45c787(0x16b)]('🕘'), await _0x5593ed[_0x45c787(0x165)](_0x45c787(0x16e));
                const _0x3fd412 = 'https://api.prabath-md.tech/api/npmsearch?q=' + encodeURIComponent(_0xb888b5), _0x2a3e1c = await _0x4099c2[_0x45c787(0x151)](_0x3fd412), _0x3cc62b = _0x2a3e1c['data'];
                if (_0x3cc62b && _0x3cc62b[_0x45c787(0x14c)] && _0x3cc62b['data']['data']) {
                    const {
                            name: _0x50f941,
                            description: _0x53a436,
                            version: _0x238e71,
                            packageLink: _0x1bf9c5,
                            downloadLink: _0x5a6fec,
                            publishedDate: _0x5461b9,
                            owner: _0x4039a3,
                            homepage: _0x5cb8a7,
                            license: _0x34cba5,
                            readme: _0x2be88a
                        } = _0x3cc62b[_0x45c787(0x14c)][_0x45c787(0x14c)], _0x215036 = _0x45c787(0x169) + _0x5593ed[_0x45c787(0x170)] + '_,*\x0aHere\x20is\x20your\x20NPM\x20Stalk\x20Results:\x0a\x0a' + (_0x45c787(0x166) + _0x50f941 + _0x45c787(0x172) + _0x4039a3 + '\x0a*Version:*\x20' + _0x238e71 + '\x0a') + (_0x45c787(0x168) + _0x5461b9 + '\x0a*Description:*\x20' + _0x53a436 + '\x0a') + (_0x45c787(0x171) + _0x1bf9c5 + _0x45c787(0x162) + _0x5a6fec + '\x0a') + (_0x45c787(0x14d) + _0x5cb8a7 + _0x45c787(0x164) + _0x34cba5 + '\x0a') + (_0x45c787(0x16f) + (_0x2be88a || _0x45c787(0x154)) + _0x45c787(0x15c));
                    await _0x241c7c[_0x45c787(0x158)](_0x5593ed['from'], { 'text': _0x215036 }, { 'quoted': _0x5593ed }), await _0x5593ed[_0x45c787(0x16b)]('✅');
                } else
                    throw new Error(_0x45c787(0x16d));
            } catch (_0xc3d0f4) {
                console['error']('Error\x20getting\x20Gifted\x20API\x20response:', _0xc3d0f4[_0x45c787(0x15f)]), _0x5593ed[_0x45c787(0x165)]('Error\x20getting\x20response\x20from\x20Gifted\x20API.'), await _0x5593ed[_0x45c787(0x16b)]('❌');
            }
        }
    };
export default npmstalk;
