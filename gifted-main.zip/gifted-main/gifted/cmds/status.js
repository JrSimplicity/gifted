(function (_0x35e3a7, _0x45c490) {
    const _0x272371 = _0xf3d1, _0x483643 = _0x35e3a7();
    while (!![]) {
        try {
            const _0x3ae9df = parseInt(_0x272371(0xa9)) / 0x1 + parseInt(_0x272371(0xae)) / 0x2 + -parseInt(_0x272371(0x94)) / 0x3 + parseInt(_0x272371(0xb5)) / 0x4 + -parseInt(_0x272371(0xab)) / 0x5 + -parseInt(_0x272371(0xa8)) / 0x6 + -parseInt(_0x272371(0xa4)) / 0x7;
            if (_0x3ae9df === _0x45c490)
                break;
            else
                _0x483643['push'](_0x483643['shift']());
        } catch (_0x1cc613) {
            _0x483643['push'](_0x483643['shift']());
        }
    }
}(_0x2829, 0x84ec0));
import _0x17b860 from '../../set.cjs';
import _0x30d876 from 'fs';
function _0xf3d1(_0xdc9f0a, _0x7f0c2c) {
    const _0x28290e = _0x2829();
    return _0xf3d1 = function (_0xf3d123, _0x6b7cba) {
        _0xf3d123 = _0xf3d123 - 0x92;
        let _0x15c032 = _0x28290e[_0xf3d123];
        return _0x15c032;
    }, _0xf3d1(_0xdc9f0a, _0x7f0c2c);
}
const handleGreeting = async (_0x597c1d, _0x2fe56b) => {
    const _0x2e61d6 = _0xf3d1, _0x285f97 = await _0x2fe56b['decodeJid'](_0x2fe56b[_0x2e61d6(0x9d)]['id']), _0x4d63d1 = [
            _0x285f97,
            _0x17b860[_0x2e61d6(0xaf)] + _0x2e61d6(0xa2)
        ][_0x2e61d6(0x98)](_0x597c1d[_0x2e61d6(0x9c)]);
    try {
        const _0x29023f = _0x597c1d[_0x2e61d6(0x97)][_0x2e61d6(0xac)](), _0x40069f = [
                _0x2e61d6(0xa6),
                _0x2e61d6(0x9e),
                _0x2e61d6(0xa5),
                _0x2e61d6(0x93),
                _0x2e61d6(0xb6),
                _0x2e61d6(0xb2),
                _0x2e61d6(0x92),
                _0x2e61d6(0xa1),
                _0x2e61d6(0x9f),
                'oh',
                'take',
                _0x2e61d6(0x9a),
                'do',
                'mee'
            ];
        if (_0x40069f[_0x2e61d6(0x98)](_0x29023f)) {
            if (!_0x4d63d1)
                return _0x597c1d[_0x2e61d6(0xad)](_0x2e61d6(0x96));
            if (_0x597c1d[_0x2e61d6(0xb3)] && _0x597c1d[_0x2e61d6(0xb3)][_0x2e61d6(0xb1)] && _0x597c1d[_0x2e61d6(0xb3)]['extendedTextMessage'][_0x2e61d6(0xa3)]) {
                const _0x58251e = _0x597c1d['message'][_0x2e61d6(0xb1)]['contextInfo'][_0x2e61d6(0x9b)], _0x324a60 = _0x597c1d[_0x2e61d6(0x9c)];
                if (_0x58251e) {
                    if (_0x58251e['imageMessage']) {
                        const _0x284833 = _0x58251e[_0x2e61d6(0x99)][_0x2e61d6(0x95)], _0x3b4818 = await _0x2fe56b[_0x2e61d6(0xa0)](_0x58251e[_0x2e61d6(0x99)]);
                        await _0x2fe56b[_0x2e61d6(0xa7)](_0x324a60, {
                            'image': { 'url': _0x3b4818 },
                            'caption': _0x284833,
                            'contextInfo': {
                                'mentionedJid': [_0x597c1d[_0x2e61d6(0x9c)]],
                                'forwardingScore': 0x270f,
                                'isForwarded': ![]
                            }
                        });
                    }
                    if (_0x58251e[_0x2e61d6(0xb4)]) {
                        const _0x6176d7 = _0x58251e['videoMessage'][_0x2e61d6(0x95)], _0x5ad92a = await _0x2fe56b[_0x2e61d6(0xa0)](_0x58251e['videoMessage']);
                        await _0x2fe56b[_0x2e61d6(0xa7)](_0x324a60, {
                            'video': { 'url': _0x5ad92a },
                            'caption': _0x6176d7,
                            'contextInfo': {
                                'mentionedJid': [_0x597c1d[_0x2e61d6(0x9c)]],
                                'forwardingScore': 0x270f,
                                'isForwarded': ![]
                            }
                        });
                    }
                }
            }
        }
    } catch (_0x567342) {
        console[_0x2e61d6(0xaa)](_0x2e61d6(0xb0), _0x567342);
    }
};
function _0x2829() {
    const _0x46b6a5 = [
        '1934508RHQbDY',
        'giv',
        'upload',
        'sent',
        '2263281mxOEUa',
        'caption',
        '*📛\x20THIS\x20IS\x20AN\x20OWNER\x20COMMAND*',
        'body',
        'includes',
        'imageMessage',
        'get',
        'quotedMessage',
        'sender',
        'user',
        'statusdown',
        'sent\x20me',
        'downloadAndSaveMediaMessage',
        'send\x20me',
        '@s.whatsapp.net',
        'contextInfo',
        '976598HmoAEP',
        'take',
        'send',
        'sendMessage',
        '33420vDOMQU',
        '810206YQrdWY',
        'error',
        '1915600sJdjZH',
        'toLowerCase',
        'reply',
        '1066492HWGTDZ',
        'OWNER_NUMBER',
        'Error:',
        'extendedTextMessage',
        'save',
        'message',
        'videoMessage'
    ];
    _0x2829 = function () {
        return _0x46b6a5;
    };
    return _0x2829();
}
export default handleGreeting;
